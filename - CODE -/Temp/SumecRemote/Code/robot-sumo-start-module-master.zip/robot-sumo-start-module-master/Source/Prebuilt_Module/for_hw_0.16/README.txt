===Prerequisite===
avr-gcc and avrdude needs to be installed

===To compile===
make

===To flash to target (using avrispmkII programmer)===
make flash

If you have a different programmer edit the Makefile
