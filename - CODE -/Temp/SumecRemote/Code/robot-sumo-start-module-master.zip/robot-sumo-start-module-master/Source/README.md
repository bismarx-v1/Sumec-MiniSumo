Source
====================
Generic_ARM - Generic and "easy" to understand code used when connecting IR reciever directly to an ARM microcontroller.

Generic_AVR - Generic and "easy" to understand code used when connecting IR reciever directly to an AVR microcontroller. 

Prebuilt_Module - This is the code loaded on the prebuilt modules, it is hard to understand since it has been optimized to fit in a 1k flash.

Remote_Control - This is the code loaded on the remotes. 
