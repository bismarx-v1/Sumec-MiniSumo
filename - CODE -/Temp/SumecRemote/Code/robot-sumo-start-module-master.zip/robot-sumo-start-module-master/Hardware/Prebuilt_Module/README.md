Read me
=====================

The prebuilt modules are intended to be manufactured in larger quantities with pick and place machinery, this is to reduce size and cost.
The microcontroller on the prebuilt module has a very small amount of flash therefore the code is optimised for size and not so easy to understand.
If you have designed your own hardware and want to create code for this it is better to look at the code in the "Generic" folders.

Harware Version history
=====
Hardware version 0.16 is the version that was first sold at RobotChallenge 2012
