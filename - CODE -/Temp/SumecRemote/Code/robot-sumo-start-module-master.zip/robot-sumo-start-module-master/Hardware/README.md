Hardware
====================

Prebuilt_Module - this is the module built with pick and place machines.

Remote_Control - used by referees

