Robot-sumo start module
=====================
Visit http://www.startmodule.com for information of how the start module system works.

This page is mainly for those who are interested in the sourcecode and schematics of the start module.

Purpose
====================
The purpose of this git repository is to maintain the robot-sumo start module system which is an open source and open hardware project.n
The purpose of the module is to make robot-sumo matches more fair and less time consuming by eliminating the possibilites of false starts.
This is done by each robot having a receiver(start module) that are programmed to suply the robot with at start signal when the referee sends the signal via an IR-remote. 
